const express = require("express");
const http = require("http");
const WebSocket = require("ws");
const path = require("path");

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });
const PORT = process.env.PORT || 3000;
const MAX_PLAYERS = 10;
const players = new Map();

app.use(express.static(path.join(__dirname, "..", "public")));
app.get("/health", (_req, res) => res.json({ ok: true, players: players.size }));

function send(ws, data) {
  if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(data));
}
function broadcast(data, exceptId = null) {
  const msg = JSON.stringify(data);
  for (const [id, client] of players) {
    if (id !== exceptId && client.ws.readyState === WebSocket.OPEN) client.ws.send(msg);
  }
}

wss.on("connection", (ws) => {
  if (players.size >= MAX_PLAYERS) {
    send(ws, { type: "full", message: "الغرفة ممتلئة حاليًا (10 لاعبين)." });
    ws.close();
    return;
  }

  const id = Math.random().toString(36).slice(2, 10);
  const player = {
    id, ws,
    name: "لاعب",
    x: (Math.random() - 0.5) * 5,
    z: 8 + Math.random() * 4,
    rot: 0,
    color: ["#3b82f6", "#e879f9", "#22c55e", "#f59e0b", "#06b6d4"][players.size % 5]
  };
  players.set(id, player);

  send(ws, {
    type: "welcome",
    id,
    players: [...players.values()].filter(p => p.id !== id).map(({id,name,x,z,rot,color}) => ({id,name,x,z,rot,color}))
  });
  broadcast({ type: "join", player: { id, name: player.name, x: player.x, z: player.z, rot: player.rot, color: player.color } }, id);
  broadcast({ type: "count", count: players.size });

  ws.on("message", (raw) => {
    let msg;
    try { msg = JSON.parse(raw.toString()); } catch { return; }

    if (msg.type === "move") {
      const x = Number(msg.x), z = Number(msg.z), rot = Number(msg.rot);
      if (![x,z,rot].every(Number.isFinite)) return;
      // Keep clients inside the small prototype city.
      player.x = Math.max(-46, Math.min(46, x));
      player.z = Math.max(-46, Math.min(46, z));
      player.rot = rot;
      broadcast({ type: "move", id, x: player.x, z: player.z, rot: player.rot }, id);
    } else if (msg.type === "name") {
      const name = String(msg.name || "لاعب").trim().slice(0, 16) || "لاعب";
      player.name = name;
      broadcast({ type: "name", id, name }, id);
    } else if (msg.type === "chat") {
      const text = String(msg.text || "").trim().slice(0, 120);
      if (text) broadcast({ type: "chat", id, name: player.name, text });
    }
  });

  ws.on("close", () => {
    players.delete(id);
    broadcast({ type: "leave", id });
    broadcast({ type: "count", count: players.size });
  });
});

server.listen(PORT, "0.0.0.0", () => {
  console.log(`City Life Online running on http://localhost:${PORT}`);
});