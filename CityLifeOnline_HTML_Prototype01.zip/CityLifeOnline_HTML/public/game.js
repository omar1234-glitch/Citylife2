import * as THREE from "three";

const mount = document.getElementById("game");
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x9bc6df);
scene.fog = new THREE.Fog(0x9bc6df, 55, 145);

const camera = new THREE.PerspectiveCamera(65, innerWidth / innerHeight, 0.1, 220);
const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: "high-performance" });
renderer.setSize(innerWidth, innerHeight);
renderer.setPixelRatio(Math.min(devicePixelRatio, 1.5));
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
mount.appendChild(renderer.domElement);

scene.add(new THREE.HemisphereLight(0xddeeff, 0x65704e, 2.0));
const sun = new THREE.DirectionalLight(0xffedcf, 2.2);
sun.position.set(-35, 65, 30);
sun.castShadow = true;
sun.shadow.mapSize.set(1024, 1024);
sun.shadow.camera.left = -65; sun.shadow.camera.right = 65;
sun.shadow.camera.top = 65; sun.shadow.camera.bottom = -65;
scene.add(sun);

const mat = (color, roughness=0.85) => new THREE.MeshStandardMaterial({ color, roughness });
const mats = {
  grass: mat(0x547c4b), road: mat(0x30353b), line: mat(0xf3df9c),
  sidewalk: mat(0xb8b7ae), glass: new THREE.MeshStandardMaterial({color:0x75b9d1, roughness:.25, metalness:.15}),
  trunk: mat(0x72503a), leaf: mat(0x2e7046), white: mat(0xe9e5d8)
};
function box(name, x,y,z, sx,sy,sz, material, cast=true) {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(sx,sy,sz), material);
  mesh.name=name; mesh.position.set(x,y,z); mesh.castShadow=cast; mesh.receiveShadow=true; scene.add(mesh); return mesh;
}
box("ground",0,-.35,0,110,.5,110,mats.grass,false);
box("road",0,-.08,0,13,.12,110,mats.road,false);
box("road",0,-.07,0,110,.13,13,mats.road,false);
for(let z=-49;z<=49;z+=8) box("road-line",0,.005,z,.18,.025,3,mats.line,false);
for(let x=-49;x<=49;x+=8) box("road-line",x,.01,0,3,.025,.18,mats.line,false);
for(const [x,z] of [[-7,-7],[7,-7],[-7,7],[7,7]]) box("sidewalk",x,.02,z,2,.12,2,mats.sidewalk,false);

const landmarks=[];
function building(name,x,z,w,h,d,color,type="home"){
  const body=box(name,x,h/2,z,w,h,d,mat(color));
  box("roof",x,h+.13,z,w+.45,.26,d+.45,mat(0x3b4650));
  box("door",x,h>10?1.2:1,z+d/2+.06,2,2.1,.12,mat(0x513b2c));
  for(let yy=3;yy<h-1;yy+=3.2){
    for(let xx=-w/2+2;xx<w/2-1;xx+=3.4){
      box("window",x+xx,yy,z+d/2+.075,1.35,1.35,.08,mats.glass,false);
    }
  }
  landmarks.push({name,type,x,z,r:Math.max(w,d)*.75+4});
  return body;
}
building("منزلك", -25,-24,15,8,14,0xd4bd9a,"home");
building("منزل الجار",25,-24,15,10,14,0xb7c5d1,"home");
building("متجر المدينة",-25,24,17,11,15,0xe0d7c6,"shop");
building("مركز الوظائف",26,25,18,14,16,0xb8c4ce,"job");
building("مقهى المدينة",0,-39,18,7,10,0xd5a879,"cafe");

function tree(x,z){
  const trunk=new THREE.Mesh(new THREE.CylinderGeometry(.22,.3,2,7),mats.trunk); trunk.position.set(x,1,z); trunk.castShadow=true; scene.add(trunk);
  const crown=new THREE.Mesh(new THREE.SphereGeometry(1.45,9,7),mats.leaf); crown.position.set(x,3,z); crown.castShadow=true; scene.add(crown);
}
for(const [x,z] of [[18,3],[31,3],[18,12],[31,12],[-39,4],[-39,12],[39,-39]]) tree(x,z);

const park=box("park",25,.015,8,22,.1,17,mat(0x477b45),false);
const carGroup=new THREE.Group(); carGroup.position.set(10,.72,-8); scene.add(carGroup);
const carBody=new THREE.Mesh(new THREE.BoxGeometry(4, .9, 2),mat(0x1c66a8)); carBody.position.y=.2; carBody.castShadow=true; carGroup.add(carBody);
const cabin=new THREE.Mesh(new THREE.BoxGeometry(2.1,.8,1.65),mats.glass); cabin.position.set(-.15,.95,0); carGroup.add(cabin);
for(const x of [-1.3,1.3]) for(const z of [-1,1]){
  const wheel=new THREE.Mesh(new THREE.CylinderGeometry(.38,.38,.22,12),mat(0x17191d));
  wheel.rotation.x=Math.PI/2; wheel.position.set(x,-.28,z); carGroup.add(wheel);
}
landmarks.push({name:"سيارة",type:"car",x:10,z:-8,r:5});

function makeAvatar(color=0x2776d2){
  const group=new THREE.Group();
  const body=new THREE.Mesh(new THREE.CapsuleGeometry(.43,.85,4,8),mat(color));
  body.position.y=1.05; body.castShadow=true; group.add(body);
  const head=new THREE.Mesh(new THREE.SphereGeometry(.29,12,10),mat(0xe6b995));
  head.position.y=1.95; head.castShadow=true; group.add(head);
  scene.add(group); return group;
}
const player=makeAvatar();
player.position.set(0,0,8);

const otherPlayers=new Map();
let myId=null, ws=null, connected=false, lastNet=0, money=500, cameraMode=0;
let moveX=0, moveZ=0, yaw=0;
const statusEl=document.getElementById("status");
const countEl=document.getElementById("playerCount");
const connectionEl=document.getElementById("connection");
function setStatus(t){statusEl.textContent=t;}
function addOther(p){
  if(otherPlayers.has(p.id)) return;
  const avatar=makeAvatar(p.color ? new THREE.Color(p.color).getHex() : 0xe879f9);
  avatar.position.set(p.x,0,p.z); avatar.rotation.y=p.rot||0;
  otherPlayers.set(p.id,{avatar,name:p.name||"لاعب"});
}
function connect(){
  const proto=location.protocol==="https:"?"wss":"ws";
  ws=new WebSocket(`${proto}://${location.host}`);
  ws.onopen=()=>{connected=true;connectionEl.textContent="متصل";connectionEl.style.color="#86efac";};
  ws.onclose=()=>{connected=false;connectionEl.textContent="غير متصل";connectionEl.style.color="#fca5a5";setStatus("الاتصال انقطع. حدّث الصفحة لإعادة المحاولة.");};
  ws.onerror=()=>{connectionEl.textContent="تعذر الاتصال";};
  ws.onmessage=(ev)=>{
    const m=JSON.parse(ev.data);
    if(m.type==="welcome"){myId=m.id;m.players.forEach(addOther);countEl.textContent=`${otherPlayers.size+1}/10`;}
    if(m.type==="join"){addOther(m.player);countEl.textContent=`${otherPlayers.size+1}/10`;}
    if(m.type==="leave"){const p=otherPlayers.get(m.id);if(p){scene.remove(p.avatar);otherPlayers.delete(m.id);}countEl.textContent=`${otherPlayers.size+1}/10`;}
    if(m.type==="move"){const p=otherPlayers.get(m.id);if(p){p.avatar.position.set(m.x,0,m.z);p.avatar.rotation.y=m.rot;}}
    if(m.type==="name"){const p=otherPlayers.get(m.id);if(p)p.name=m.name;}
    if(m.type==="count")countEl.textContent=`${m.count}/10`;
    if(m.type==="chat")appendChat(m.name,m.text);
    if(m.type==="full")setStatus(m.message);
  };
}
connect();

const joystick=document.getElementById("joystick"), stick=document.getElementById("stick");
let joyPointer=null;
function joystickMove(e){
  const r=joystick.getBoundingClientRect(), cx=r.left+r.width/2, cy=r.top+r.height/2;
  let dx=e.clientX-cx, dy=e.clientY-cy, len=Math.hypot(dx,dy), max=34;
  if(len>max){dx=dx/len*max;dy=dy/len*max;}
  stick.style.transform=`translate(${dx}px,${dy}px)`;
  moveX=dx/max; moveZ=dy/max;
}
joystick.addEventListener("pointerdown",e=>{joyPointer=e.pointerId;joystick.setPointerCapture(joyPointer);joystickMove(e);});
joystick.addEventListener("pointermove",e=>{if(e.pointerId===joyPointer)joystickMove(e);});
function stopJoy(){joyPointer=null;moveX=0;moveZ=0;stick.style.transform="translate(0,0)";}
joystick.addEventListener("pointerup",stopJoy);joystick.addEventListener("pointercancel",stopJoy);

function nearestLandmark(){
  let best=null, dist=Infinity;
  for(const l of landmarks){const d=Math.hypot(player.position.x-l.x,player.position.z-l.z);if(d<dist){best=l;dist=d;}}
  return dist<best.r+2?best:null;
}
function modal(title,text,extra=""){
  document.getElementById("modalTitle").textContent=title;
  document.getElementById("modalText").textContent=text;
  document.getElementById("modalExtra").textContent=extra;
  document.getElementById("modal").classList.remove("hidden");
}
function interact(){
  const l=nearestLandmark();
  if(!l){setStatus("اقترب من بيت أو متجر أو سيارة أو مكان عمل.");return;}
  document.getElementById("locationTitle").textContent=l.name;
  if(l.type==="home") modal(l.name,"هذا منزل تجريبي. في التحديث القادم سنضيف شراء البيوت والدخول والتأثيث.","نموذج أولي");
  else if(l.type==="shop") modal("متجر المدينة","أنت أمام المتجر. يمكننا إضافة التسوق وشراء الأغراض في المرحلة القادمة.");
  else if(l.type==="job") modal("مركز الوظائف","اختر وظيفة تجريبية: توصيل طلبات أو العمل في متجر.", "اضغط «وظيفة» للحصول على مكافأة تجريبية.");
  else if(l.type==="cafe") modal("مقهى المدينة","مكان مناسب للقاء أصحابك والدردشة.");
  else if(l.type==="car") modal("سيارة المدينة","السيارة للعرض في هذه النسخة. القيادة الفعلية قيد التطوير.");
}
document.getElementById("interactBtn").addEventListener("click",interact);
document.getElementById("cameraBtn").addEventListener("click",()=>{cameraMode=(cameraMode+1)%2;setStatus(cameraMode===0?"كاميرا الشخص الثالث":"كاميرا أقرب للشخصية");});
document.getElementById("houseBtn").addEventListener("click",()=>{player.position.set(-19,0,-15);setStatus("انتقلت إلى منزلك التجريبي.");});
document.getElementById("jobBtn").addEventListener("click",()=>{money+=50;document.getElementById("money").textContent=money;modal("مهمة تجريبية مكتملة","حصلت على 50 جنيهًا افتراضيًا. نظام الوظائف الحقيقي قادم لاحقًا.");});
document.getElementById("chatBtn").addEventListener("click",()=>document.getElementById("chatPanel").classList.remove("hidden"));
document.getElementById("closeChat").addEventListener("click",()=>document.getElementById("chatPanel").classList.add("hidden"));
document.getElementById("closeModal").addEventListener("click",()=>document.getElementById("modal").classList.add("hidden"));
document.getElementById("modalOk").addEventListener("click",()=>document.getElementById("modal").classList.add("hidden"));
function appendChat(name,text){const p=document.createElement("p");const b=document.createElement("b");b.textContent=name+": ";p.append(b,document.createTextNode(text));const box=document.getElementById("chatMessages");box.appendChild(p);box.scrollTop=box.scrollHeight;}
document.getElementById("chatForm").addEventListener("submit",e=>{e.preventDefault();const input=document.getElementById("chatInput");const text=input.value.trim();if(text&&connected){ws.send(JSON.stringify({type:"chat",text}));appendChat("أنت",text);input.value="";}});

const clock=new THREE.Clock();
function animate(){
  requestAnimationFrame(animate);
  const dt=Math.min(clock.getDelta(),.04);
  const forward=new THREE.Vector3(Math.sin(yaw),0,Math.cos(yaw));
  const right=new THREE.Vector3(Math.cos(yaw),0,-Math.sin(yaw));
  const dir=right.multiplyScalar(moveX).add(forward.multiplyScalar(moveZ));
  if(dir.lengthSq()>.02){
    dir.normalize(); player.position.addScaledVector(dir,5.1*dt);
    player.position.x=THREE.MathUtils.clamp(player.position.x,-49,49);
    player.position.z=THREE.MathUtils.clamp(player.position.z,-49,49);
    player.rotation.y=Math.atan2(dir.x,dir.z);
  }
  const target=player.position.clone().add(new THREE.Vector3(0,1.2,0));
  const distance=cameraMode===0?8:4.2;
  const desired=player.position.clone().add(new THREE.Vector3(0,3.2,distance));
  camera.position.lerp(desired,.12); camera.lookAt(target);
  const now=performance.now();
  if(connected&&ws.readyState===WebSocket.OPEN&&now-lastNet>90){
    ws.send(JSON.stringify({type:"move",x:player.position.x,z:player.position.z,rot:player.rotation.y}));
    lastNet=now;
  }
  renderer.render(scene,camera);
}
animate();
addEventListener("resize",()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);renderer.setPixelRatio(Math.min(devicePixelRatio,1.5));});
